
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Search, Copy, Check, Zap, User, ShieldCheck, Menu, X, ArrowRight,
  ExternalLink, Code, Tag, Monitor, Heart, Settings2, Sparkles, Camera,
  MapPin, Shirt, Wand2, Loader2, MessageSquarePlus, Bot, Image as ImageIcon,
  Download, Upload, ScanEye, RefreshCw, MinusCircle, Hash, BookOpen,
  Shuffle, Share2, Aperture, Film, Plus, Ghost, Palette, Tv, Lock,
  LogOut, CreditCard, AlertCircle, Briefcase, Crown, Fingerprint, Globe,
  Video, Lightbulb, PenTool, Dices, Maximize2, Database
} from 'lucide-react';
import { PROMPTS, CHARACTERS, LOCATIONS, CAMERA_DATABASE, CAMERA_STYLES, OUTFITS, generateDynamicPrompt, DNA_BASE, generatePromptsForCharacter, generateRandomCharacter } from './data';
import { Prompt, Character, Category } from './types';
import { saveImage, getImage } from './db';
import { supabase, isSupabaseConfigured, mapCharFromDB, mapPromptFromDB, mapCharToDB, mapPromptToDB } from './supabase';

const MANUS_API_KEY = "sk-DCjmhuIJhngsfc-VbAONIQR3oA-_6IrfBrh_y7UuLZgGE43SOE9WKnqSoKtsvWL2Gl9LPqD37QFGPwNenPwTBfltPADZ";
const OPENROUTER_API_KEY = "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";

type Tier = 'free' | 'lite' | 'pro';

interface UserProfile {
  email: string;
  name: string;
  tier: Tier;
}

// --- Shared Components ---

const Navbar: React.FC<{ 
    currentPath: string; 
    onNavigate: (path: string) => void; 
    user: UserProfile | null;
}> = ({ currentPath, onNavigate, user }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dbConfigured = isSupabaseConfigured();

  const links = [
    { name: 'Início', path: '#home' },
    { name: 'Gerador', path: '#generator' },
    { name: 'Marketplace', path: '#marketplace' },
    { name: 'Personagens', path: '#characters' },
    { name: 'Preços', path: '#pricing' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-[#1a120b]/90 backdrop-blur-xl border-b border-[#3a2d25]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('#home')}>
            <div className="w-8 h-8 bg-[#e5e5e5] rounded-lg flex items-center justify-center text-[#1a120b] font-bold italic shadow-lg shadow-black/20">K</div>
            <span className="text-xl font-bold tracking-tight text-[#e5e5e5] editorial-spacing">KAIZEN <span className="font-light text-[#a89f91]">PROMPTS</span></span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            {links.map((link) => (
              <button
                key={link.name}
                onClick={() => onNavigate(link.path)}
                className={`text-[10px] font-bold uppercase tracking-widest transition-all ${
                  currentPath === link.path ? 'text-[#e5e5e5] border-b-2 border-[#e5e5e5] pb-1' : 'text-[#a89f91] hover:text-[#e5e5e5]'
                }`}
              >
                {link.name}
              </button>
            ))}
            
            {user && (
                <div className="flex items-center gap-3 pl-4 border-l border-[#3a2d25]">
                    {dbConfigured && <div className="text-green-500" title="Supabase Connected"><Database size={14} /></div>}
                    <div className="flex flex-col text-right">
                        <span className="text-[10px] font-bold text-[#e5e5e5]">{user.name}</span>
                        <span className={`text-[9px] uppercase font-bold tracking-widest ${user.tier === 'pro' ? 'text-[#d4b483]' : user.tier === 'lite' ? 'text-blue-400' : 'text-[#a89f91]'}`}>
                            {user.tier.toUpperCase()} PLAN
                        </span>
                    </div>
                </div>
            )}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-[#a89f91] hover:text-[#e5e5e5]">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-[#241a15] border-b border-[#3a2d25] p-4 space-y-4">
          {links.map((link) => (
            <button
              key={link.name}
              onClick={() => { onNavigate(link.path); setIsOpen(false); }}
              className="block w-full text-left text-xs font-bold uppercase tracking-widest text-[#a89f91] hover:text-[#e5e5e5]"
            >
              {link.name}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};

const CopyButton: React.FC<{ text: string, label?: string }> = ({ text, label = 'Copiar' }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all w-full shadow-sm border
        ${copied 
          ? 'bg-green-900/50 border-green-800 text-green-200' 
          : 'bg-[#241a15] border-[#3a2d25] text-[#e5e5e5] hover:border-[#e5e5e5]'}`}
    >
      {copied ? <Check size={14} /> : <Copy size={14} />}
      {copied ? 'Copiado' : label}
    </button>
  );
};

// --- Image Generation Component ---

const ImagePreview: React.FC<{ promptId: string, promptText: string, autoGenerate?: boolean }> = ({ promptId, promptText, autoGenerate = false }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [queued, setQueued] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    checkCache();
    return () => { isMounted.current = false; };
  }, [promptId]);

  const checkCache = async () => {
    const cached = await getImage(promptId);
    if (cached && isMounted.current) {
      setImageUrl(cached);
    }
  };

  const generateImage = async () => {
    if (!isMounted.current) return;
    
    const cached = await getImage(promptId);
    if (cached) {
      setImageUrl(cached);
      setQueued(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const response = await fetch("https://api.manus.im/v1/images/generations", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${MANUS_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          prompt: promptText,
          n: 1,
          size: "1024x1024",
          model: "dall-e-3",
          response_format: "b64_json"
        })
      });

      if (!response.ok) {
        throw new Error(`Manus API Error: ${response.statusText}`);
      }

      const data = await response.json();
      
      let foundImage = false;
      if (data.data && data.data[0] && data.data[0].b64_json) {
         const base64String = data.data[0].b64_json;
         const fullBase64 = `data:image/png;base64,${base64String}`;
         if (isMounted.current) {
           setImageUrl(fullBase64);
           foundImage = true;
         }
         await saveImage(promptId, fullBase64);
      }
      if (!foundImage && isMounted.current) throw new Error("Modelo não retornou imagem.");
    } catch (e: any) {
      console.error("Erro na geração:", e);
      if (isMounted.current) setError("Erro. Tente novamente.");
    } finally {
      if (isMounted.current) { setLoading(false); setQueued(false); }
    }
  };

  useEffect(() => {
    if (autoGenerate && !imageUrl && !loading && !queued && !error) {
        getImage(promptId).then(cached => {
            if (!cached && isMounted.current) {
                setQueued(true);
                generateImage(); // Direct call for simplification in this queue example
            } else if (cached && isMounted.current) {
                setImageUrl(cached);
            }
        });
    }
  }, [autoGenerate, promptId]);

  if (imageUrl) {
    return (
      <div className="mt-4 relative group animate-in fade-in duration-700">
        <img src={imageUrl} alt="Generated Preview" className="w-full h-auto rounded-2xl shadow-lg border border-[#3a2d25]" />
        <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <a href={imageUrl} download={`kaizen-${promptId}.png`} className="bg-[#e5e5e5] text-[#1a120b] px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-lg flex items-center gap-2 hover:bg-white">
                <Download size={12} /> Salvar
            </a>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-4">
      {error && (
          <div className="p-3 bg-red-900/20 border border-red-900/50 rounded-xl mb-2 flex items-start gap-2">
              <AlertCircle size={14} className="text-red-400 mt-0.5 shrink-0"/>
              <p className="text-red-400 text-[10px] leading-tight">{error}</p>
          </div>
      )}
      {queued || loading ? (
         <div className="w-full py-8 bg-[#241a15] border border-[#3a2d25] rounded-2xl flex flex-col items-center justify-center gap-2">
            <Loader2 size={16} className="animate-spin text-[#a89f91]" />
            <span className="text-[9px] font-bold uppercase tracking-widest text-[#a89f91]">Renderizando...</span>
         </div>
      ) : (
        <button onClick={() => { setQueued(true); generateImage(); }} className="w-full py-2 bg-[#2a201b] border border-[#3a2d25] text-[#d4b483] rounded-xl font-bold uppercase tracking-widest text-[9px] hover:bg-[#3a2d25] flex items-center justify-center gap-2">
          <ImageIcon size={12} /> Visualizar Imagem
        </button>
      )}
    </div>
  );
};

// --- Prompt Detail Modal ---

const PromptModal: React.FC<{ prompt: Prompt, onClose: () => void }> = ({ prompt, onClose }) => {
    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-[#1a120b] border border-[#3a2d25] w-full max-w-3xl rounded-[2rem] shadow-2xl max-h-[90vh] overflow-y-auto relative animate-in zoom-in-95 duration-200">
                <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-[#241a15] rounded-full text-[#a89f91] hover:text-[#e5e5e5] hover:bg-[#3a2d25] transition-colors z-10">
                    <X size={20} />
                </button>

                <div className="p-8">
                    <div className="flex gap-2 mb-4">
                         <span className="px-3 py-1 rounded-full bg-[#3a2d25] text-[10px] uppercase font-bold text-[#d4b483] border border-[#5c473d]">{prompt.category}</span>
                         {prompt.isPremium && <span className="px-3 py-1 rounded-full bg-[#d4b483] text-[10px] uppercase font-bold text-[#1a120b] flex items-center gap-1"><Crown size={10} /> Pro</span>}
                    </div>
                    
                    <h2 className="text-3xl font-bold text-[#e5e5e5] mb-2">{prompt.title}</h2>
                    <p className="text-[#a89f91] text-sm mb-8">{prompt.description}</p>

                    <div className="grid md:grid-cols-2 gap-8">
                        <div>
                             <div className="flex items-center gap-2 mb-3 text-[#e5e5e5]">
                                <Code size={16} /> <span className="text-[10px] font-bold uppercase tracking-widest">Prompt Completo</span>
                             </div>
                             <div className="bg-[#0f0a06] p-4 rounded-2xl border border-[#3a2d25] mb-4">
                                 <p className="text-xs text-[#a89f91] font-mono leading-relaxed whitespace-pre-wrap">{prompt.fullPrompt}</p>
                             </div>
                             <CopyButton text={prompt.fullPrompt} label="Copiar Prompt" />
                             
                             <div className="mt-6 flex flex-wrap gap-2">
                                {prompt.tags.map(t => <span key={t} className="px-2 py-1 bg-[#241a15] rounded text-[9px] text-[#5c473d] uppercase font-bold tracking-widest">#{t}</span>)}
                             </div>
                        </div>

                        <div>
                            <div className="flex items-center gap-2 mb-3 text-[#e5e5e5]">
                                <ImageIcon size={16} /> <span className="text-[10px] font-bold uppercase tracking-widest">Preview & Render</span>
                             </div>
                             <div className="bg-[#241a15] p-4 rounded-2xl border border-[#3a2d25]">
                                <ImagePreview promptId={prompt.id} promptText={prompt.fullPrompt} autoGenerate={false} />
                             </div>
                             <div className="mt-4 p-4 bg-[#241a15] rounded-xl border border-[#3a2d25]">
                                 <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#d4b483] mb-2">Modelo Recomendado</h4>
                                 <p className="text-xs text-[#a89f91]">{prompt.modelRecommendation}</p>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Pages ---

const HomePage: React.FC<{ onNavigate: (p: string) => void }> = ({ onNavigate }) => {
  return (
    <div className="pb-32 bg-[#1a120b]">
      <section className="relative pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#3a2d25] rounded-full text-[10px] font-bold tracking-widest text-[#d4b483] uppercase mb-8 shadow-xl shadow-black/20 border border-[#4a3a30]">
            <Sparkles size={14} />
            O Motor de Realismo IA
          </div>
          <h1 className="text-6xl md:text-[8rem] font-bold text-[#e5e5e5] mb-8 editorial-spacing tracking-tighter leading-none">
            Cru. Real. <br />
            <span className="text-[#a89f91]">DNA UGC.</span>
          </h1>
          <p className="max-w-xl mx-auto text-lg text-[#a89f91] mb-12 leading-relaxed font-light">
            Consistência projetada para a próxima geração de conteúdo IA. Crie saídas de personagens 100% consistentes com nosso gerador de ponta.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <button onClick={() => onNavigate('#generator')} className="w-full sm:w-auto px-10 py-5 bg-[#e5e5e5] text-[#1a120b] rounded-2xl font-bold uppercase tracking-widest text-xs hover:scale-105 transition-all shadow-2xl shadow-black/10 flex items-center gap-2">
              <Settings2 size={18} /> Abrir Gerador
            </button>
            <button onClick={() => onNavigate('#marketplace')} className="w-full sm:w-auto px-10 py-5 bg-transparent border border-[#3a2d25] text-[#e5e5e5] rounded-2xl font-bold uppercase tracking-widest text-xs hover:border-[#e5e5e5] hover:bg-[#241a15] transition-all shadow-sm">
              Explorar Biblioteca
            </button>
          </div>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-3 gap-8 py-20 border-t border-[#3a2d25]">
        {[
          { icon: <User />, title: "Personagens Custom", desc: "Crie e salve seus próprios modelos digitais no Character Lab (Pro)." },
          { icon: <Camera />, title: "100+ Câmeras", desc: "Banco de dados massivo com estilos reais, de Arri Alexa a Polaroid." },
          { icon: <Monitor />, title: "Multi-Motor", desc: "Otimizado para DALL-E 3 (Manus), Midjourney v6 e FLUX." }
        ].map((item, i) => (
          <div key={i} className="p-10 bg-[#241a15] rounded-[2.5rem] border border-[#3a2d25] hover:shadow-xl hover:shadow-black/20 transition-all group hover:border-[#5c473d]">
            <div className="w-12 h-12 bg-[#3a2d25] rounded-2xl flex items-center justify-center text-[#d4b483] mb-6 group-hover:bg-[#e5e5e5] group-hover:text-[#1a120b] transition-colors">
              {item.icon}
            </div>
            <h3 className="text-xl font-bold mb-3 text-[#e5e5e5]">{item.title}</h3>
            <p className="text-[#a89f91] text-sm font-light leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

const GeneratorPage: React.FC<{ allCharacters: Character[], userTier: Tier, onGoToPricing: () => void }> = ({ allCharacters, userTier, onGoToPricing }) => {
  const [character, setCharacter] = useState(allCharacters[0]);
  const [location, setLocation] = useState(LOCATIONS[0]);
  const [camera, setCamera] = useState("Random"); // Default to random
  const [outfit, setOutfit] = useState(OUTFITS[0]);
  const [customContext, setCustomContext] = useState("");
  const [generated, setGenerated] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [extraResult, setExtraResult] = useState<{type: string, content: string} | null>(null);
  const [isExtraLoading, setIsExtraLoading] = useState(false);

  // Gating Logic
  const canUseStatic = userTier !== 'free';
  const canUseAI = userTier === 'pro';

  const handleStaticGenerate = () => {
    if (!canUseStatic) { onGoToPricing(); return; }
    const prompt = generateDynamicPrompt(character, location, camera, outfit);
    setGenerated(prompt);
    setNegativePrompt("");
    setTags([]);
    setExtraResult(null);
  };

  const handleAIGenerate = async () => {
    if (!canUseAI) { onGoToPricing(); return; }
    setIsGenerating(true);
    setExtraResult(null);
    try {
      const selectedCamera = camera === "Random" 
        ? CAMERA_STYLES[Math.floor(Math.random() * CAMERA_STYLES.length)]
        : camera;

      const context = customContext.trim() ? customContext : `Local: ${location}, Roupa: ${outfit}`;

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
          "HTTP-Referer": window.location.href,
          "X-Title": "Kaizen Prompts",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          "model": "z-ai/glm-4.5-air:free",
          "messages": [
            {
              "role": "system",
              "content": `Você é um engenheiro de prompts de IA especialista em imagens ultra-realistas.
              PERSONAGEM ALVO: Nome: ${character.name}, Detalhes: ${character.desc}, DNA Visual: ${DNA_BASE}.
              CONFIGURAÇÃO DE CÂMERA: ${selectedCamera}.
              REGRAS: Gere um prompt "FULL BODY SHOT" ou "WIDE ANGLE". O ambiente e a roupa devem ser visíveis.
              SAÍDA: Apenas o texto do prompt.`
            },
            {
              "role": "user",
              "content": `Cenário: ${context}. Câmera: ${selectedCamera}.`
            }
          ]
        })
      });

      const data = await response.json();
      if (data.choices && data.choices[0]) {
        setGenerated(data.choices[0].message.content.trim());
        setNegativePrompt("");
        setTags([]);
      }
    } catch (error) {
      console.error(error);
      alert("Falha na IA.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEnhancePrompt = async () => {
    if (!generated) return;
    if (!canUseAI) { onGoToPricing(); return; }
    setIsEnhancing(true);
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          "model": "z-ai/glm-4.5-air:free",
          "messages": [
            {
              "role": "system",
              "content": `Gere um JSON com: 1. "negative" (prompt negativo, o que evitar, ex: deformidades, plastico). 2. "tags" (array de 5 strings). Apenas JSON válido.`
            },
            { "role": "user", "content": `Prompt Base: ${generated}` }
          ]
        })
      });
      const data = await response.json();
      const content = data.choices[0].message.content.replace(/```json/g, '').replace(/```/g, '').trim();
      const result = JSON.parse(content);
      setNegativePrompt(result.negative);
      setTags(result.tags);
    } catch (e) { console.error(e); } finally { setIsEnhancing(false); }
  };

  // --- GLM Functions ---
  const runGLMTask = async (taskType: string, systemPrompt: string) => {
    if (!generated) return;
    if (!canUseAI) { onGoToPricing(); return; }
    setIsExtraLoading(true);
    try {
       const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${OPENROUTER_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          "model": "z-ai/glm-4.5-air:free",
          "messages": [{ "role": "system", "content": systemPrompt }, { "role": "user", "content": `Base Prompt: "${generated}"` }]
        })
      });
      const data = await response.json();
      if(data.choices) setExtraResult({ type: taskType, content: data.choices[0].message.content });
    } catch (e) { console.error(e); } finally { setIsExtraLoading(false); }
  };

  const handleLore = () => runGLMTask("Lore / Backstory", "Escreva uma backstory curta, dramática e misteriosa (em Português) para o personagem neste cenário exato. Máximo 3 frases.");
  const handleSocial = () => runGLMTask("Legenda Social", "Escreva uma legenda engajadora para Instagram baseada nesta imagem. Inclua emojis e 5 hashtags relevantes. Tom: Influencer High-End.");
  const handleTechSpecs = () => runGLMTask("Diretor de Fotografia (Tech Specs)", "Analise o prompt e invente especificações técnicas realistas para a câmera que tirou a foto. Inclua: Câmera Modelo, Lente (mm), Abertura (f/), ISO, Shutter Speed e Iluminação. Formato de lista.");
  const handleRemix = (style: string) => runGLMTask(`Remix: ${style}`, `REESCREVA o prompt transformando o estilo visual DRASTICAMENTE para "${style}". Mantenha o personagem e a ação, mas mude a iluminação, mídia, câmera e atmosfera. Seja extremo e criativo. Retorne APENAS o novo prompt em Inglês.`);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-[#1a120b]">
      <div className="mb-16 text-center">
        <span className="text-[10px] font-bold uppercase tracking-[0.5em] text-[#a89f91] block mb-4">Laboratório</span>
        <h1 className="text-5xl font-bold editorial-spacing text-[#e5e5e5]">Gerador de Prompts</h1>
        {!canUseStatic && <div className="mt-4 px-4 py-2 bg-red-900/20 border border-red-900/50 rounded-lg inline-block text-red-400 text-xs font-bold uppercase tracking-widest">Bloqueado no Plano Free</div>}
      </div>

      <div className="grid lg:grid-cols-12 gap-12">
        <div className={`lg:col-span-5 space-y-8 ${!canUseStatic ? 'opacity-50 pointer-events-none' : ''}`}>
            <div>
              <label className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[#a89f91] mb-4">
                <User size={14} /> Selecionar Personagem
              </label>
              <div className="grid grid-cols-2 gap-3 max-h-[300px] overflow-y-auto no-scrollbar">
                {allCharacters.map(c => (
                  <button key={c.id} onClick={() => setCharacter(c)} className={`p-4 rounded-2xl text-left border transition-all ${character.id === c.id ? 'border-[#e5e5e5] bg-[#e5e5e5] text-[#1a120b]' : 'border-[#3a2d25] bg-[#241a15] text-[#e5e5e5]'}`}>
                    <p className="font-bold text-sm">{c.name}</p>
                    <p className={`text-[10px] ${character.id === c.id ? 'text-[#3a2d25]' : 'text-[#a89f91]'}`}>{c.country}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <label className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[#a89f91]">
                <MapPin size={14} /> Localização
              </label>
              <select value={location} onChange={(e) => setLocation(e.target.value)} className="w-full p-4 rounded-2xl bg-[#241a15] border border-[#3a2d25] text-[#e5e5e5] text-sm font-medium">
                {LOCATIONS.map(l => <option key={l} value={l} className="bg-[#241a15]">{l}</option>)}
              </select>
            </div>

            <div className="space-y-4">
              <label className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[#a89f91]">
                <Camera size={14} /> Câmera & Estilo (100+ Opções)
              </label>
              <select value={camera} onChange={(e) => setCamera(e.target.value)} className="w-full p-4 rounded-2xl bg-[#241a15] border border-[#3a2d25] text-[#e5e5e5] text-sm font-medium">
                 <option value="Random">✨ Aleatório (Surpreenda-me)</option>
                 {CAMERA_DATABASE.map((cat, idx) => (
                    <optgroup key={idx} label={cat.category}>
                        {cat.items.map(item => (
                            <option key={item} value={item}>{item}</option>
                        ))}
                    </optgroup>
                 ))}
              </select>
            </div>

            <div className="space-y-4">
              <label className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[#a89f91]">
                <Shirt size={14} /> Roupa
              </label>
              <select value={outfit} onChange={(e) => setOutfit(e.target.value)} className="w-full p-4 rounded-2xl bg-[#241a15] border border-[#3a2d25] text-[#e5e5e5] text-sm font-medium">
                {OUTFITS.map(o => <option key={o} value={o} className="bg-[#241a15]">{o}</option>)}
              </select>
            </div>

            <div className="space-y-4 pt-4 border-t border-[#3a2d25]">
              <label className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[#a89f91]">
                <MessageSquarePlus size={14} /> Contexto (Opcional)
              </label>
              <textarea value={customContext} onChange={(e) => setCustomContext(e.target.value)} placeholder="Ex: Comendo um hambúrguer, lutando..." className="w-full p-4 rounded-2xl bg-[#241a15] border border-[#3a2d25] text-sm font-medium h-24 resize-none text-[#e5e5e5] placeholder-[#5c473d]" />
            </div>
        </div>
        
        <div className="lg:col-span-5 flex flex-col gap-4 -mt-4">
             <button onClick={handleStaticGenerate} disabled={isGenerating} className={`w-full py-4 bg-[#241a15] border border-[#3a2d25] text-[#e5e5e5] rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-[#3a2d25] flex items-center justify-center gap-2 ${!canUseStatic ? 'cursor-not-allowed opacity-50' : ''}`}>
                {!canUseStatic && <Lock size={12}/>}
                <Settings2 size={14} /> Montagem Estática
              </button>
              
              <div className="grid grid-cols-1 gap-4">
                  <button onClick={handleAIGenerate} disabled={isGenerating} className={`w-full py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 ${canUseAI ? 'bg-[#e5e5e5] text-[#1a120b] hover:bg-white' : 'bg-[#241a15] border border-[#3a2d25] text-[#a89f91] opacity-60 cursor-pointer'}`}>
                    {!canUseAI && <Lock size={12} />}
                    {isGenerating ? <Loader2 size={14} className="animate-spin" /> : <Wand2 size={14} />}
                    Remix IA (GLM-4)
                  </button>
              </div>
        </div>

        <div className="lg:col-span-7 space-y-8">
          <div className="bg-[#241a15] border border-[#3a2d25] rounded-[3rem] p-10 h-full flex flex-col shadow-sm relative overflow-hidden">
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-bold text-lg text-[#e5e5e5]">Saída</h3>
              <div className="flex gap-2">
                 <span className="px-3 py-1 bg-[#1a120b] text-[#a89f91] text-[9px] font-bold uppercase tracking-widest rounded-full border border-[#3a2d25]">{camera === 'Random' ? 'Câmera Auto' : 'Câmera Fixa'}</span>
              </div>
            </div>

            {generated ? (
              <div className="flex-grow space-y-8 animate-in fade-in duration-500">
                <div className="bg-[#1a120b] rounded-3xl p-8 border border-[#3a2d25] relative group min-h-[150px] flex flex-col justify-center">
                  <pre className="text-sm text-[#a89f91] font-mono leading-relaxed whitespace-pre-wrap">{generated}</pre>
                </div>

                {negativePrompt && (
                   <div className="animate-in slide-in-from-bottom-4 duration-500">
                      <div className="bg-[#2a201b] rounded-3xl p-6 border border-[#3a2d25] mb-4">
                        <div className="flex items-center gap-2 mb-3 text-red-300">
                            <MinusCircle size={14} /> <span className="text-[9px] font-bold uppercase tracking-widest">Negative Prompt</span>
                        </div>
                        <p className="text-xs text-[#a89f91] font-mono leading-relaxed">{negativePrompt}</p>
                        <div className="mt-2 flex justify-end"><CopyButton text={negativePrompt} label="Copiar" /></div>
                      </div>
                      {tags.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                              {tags.map((tag, i) => (<span key={i} className="px-3 py-1 rounded-full border border-[#3a2d25] bg-[#1a120b] text-[#a89f91] text-[10px] font-bold uppercase tracking-widest flex items-center gap-1"><Hash size={10} /> {tag}</span>))}
                          </div>
                      )}
                   </div>
                )}

                <div className="space-y-4 pt-4 border-t border-[#3a2d25]">
                  <div className="flex gap-2">
                     <div className="flex-grow"><CopyButton text={generated} label="Copiar Prompt" /></div>
                     <button onClick={handleEnhancePrompt} disabled={isEnhancing || !!negativePrompt} className="px-6 bg-[#3a2d25] text-[#d4b483] rounded-xl font-bold uppercase tracking-widest text-[9px] hover:bg-[#4a3a30] transition-all disabled:opacity-50 flex items-center gap-2">
                        {!canUseAI && <Lock size={10}/>}
                        {isEnhancing ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                        {negativePrompt ? "Analisado" : "Gerar Negativos"}
                     </button>
                  </div>
                  <ImagePreview promptId={`gen-${generated.substring(0, 10).replace(/\s/g, '')}-${Date.now()}`} promptText={generated} autoGenerate={false} />
                </div>
              </div>
            ) : (
              <div className="flex-grow flex flex-col items-center justify-center text-center opacity-20">
                {isGenerating ? <Loader2 size={80} className="mb-6 animate-spin text-[#a89f91]" /> : <Code size={80} strokeWidth={1} className="mb-6 text-[#a89f91]" />}
                <p className="text-sm font-bold uppercase tracking-[0.3em] text-[#a89f91]">{isGenerating ? "Sintetizando Dados..." : "Pronto para Geração"}</p>
              </div>
            )}
          </div>

          {generated && (
             <div className="bg-[#241a15] border border-[#3a2d25] rounded-[2.5rem] p-8 animate-in slide-in-from-bottom-8 duration-700 relative overflow-hidden">
                {!canUseAI && <div className="absolute inset-0 bg-[#1a120b]/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center"><Lock size={32} className="text-[#d4b483] mb-4" /><button onClick={onGoToPricing} className="bg-[#e5e5e5] text-[#1a120b] px-6 py-2 rounded-full font-bold uppercase tracking-widest text-[10px]">Upgrade to Pro</button></div>}
                <div className="flex items-center gap-3 mb-6"><div className="bg-[#d4b483] p-2 rounded-xl text-[#1a120b]"><Bot size={18} /></div><div><h3 className="font-bold text-[#e5e5e5]">Creative Suite (GLM-4)</h3><p className="text-[10px] uppercase tracking-widest text-[#a89f91]">Aumente o realismo</p></div></div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <button onClick={handleLore} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><BookOpen size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Lore / Backstory</span></button>
                    <button onClick={handleSocial} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Share2 size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Social Caption</span></button>
                    <button onClick={handleTechSpecs} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Video size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Tech Specs</span></button>
                    {/* Insane Remix Styles */}
                    <button onClick={() => handleRemix('80s Dark Fantasy Movie')} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Ghost size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Dark Fantasy 80s</span></button>
                    <button onClick={() => handleRemix('Studio Ghibli Watercolor')} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Palette size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Ghibli Style</span></button>
                    <button onClick={() => handleRemix('Vaporwave Glitch')} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Monitor size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Vaporwave</span></button>
                    <button onClick={() => handleRemix('Analogue Horror VHS')} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><Tv size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">VHS Horror</span></button>
                    <button onClick={() => handleRemix('Renaissance Oil Painting')} disabled={isExtraLoading} className="p-4 bg-[#1a120b] border border-[#3a2d25] rounded-2xl hover:border-[#d4b483] text-left group"><PenTool size={16} className="text-[#a89f91] group-hover:text-[#d4b483] mb-3" /><span className="block text-[10px] font-bold uppercase tracking-widest text-[#e5e5e5]">Renaissance</span></button>
                </div>
                {isExtraLoading && <div className="mt-6 text-center"><Loader2 size={24} className="animate-spin text-[#d4b483] mx-auto mb-2" /><span className="text-[10px] uppercase tracking-widest text-[#a89f91]">Processando Remix...</span></div>}
                {extraResult && <div className="mt-6 bg-[#1a120b] border border-[#3a2d25] p-6 rounded-2xl animate-in fade-in"><div className="flex justify-between items-center mb-4"><span className="text-[9px] font-bold uppercase tracking-widest text-[#d4b483] border border-[#3a2d25] px-2 py-1 rounded-full">{extraResult.type}</span><button onClick={() => setExtraResult(null)}><X size={14}/></button></div><pre className="text-sm text-[#a89f91] font-mono leading-relaxed whitespace-pre-wrap mb-4">{extraResult.content}</pre><CopyButton text={extraResult.content} /></div>}
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CharacterPage: React.FC<{ characters: Character[], userTier: Tier, onAdd: (c: Character) => void, onGoToPricing: () => void, onSelect: (id: string) => void }> = ({ characters, userTier, onAdd, onGoToPricing, onSelect }) => {
    const [newChar, setNewChar] = useState({ name: '', age: 24, country: '', hair: '', eyes: '', desc: '', style: 'UGC' });
    
    const canCreate = userTier === 'pro';

    const handleRandomize = () => {
         const random = generateRandomCharacter();
         setNewChar({ ...random, desc: random.desc });
    };

    const handleSubmit = () => {
        if (!canCreate) { onGoToPricing(); return; }
        if(!newChar.name || !newChar.desc) return;
        const c: Character = {
            id: newChar.name.toLowerCase().replace(/\s/g, '-'),
            ...newChar,
            isPremium: false,
            rules: ["Criado pelo usuário"]
        };
        onAdd(c);
        setNewChar({ name: '', age: 24, country: '', hair: '', eyes: '', desc: '', style: 'UGC' });
        // Removing the alert here since App will handle navigation
    };

    return (
        <div className="max-w-7xl mx-auto px-4 py-20">
            <h1 className="text-4xl font-bold mb-2 editorial-spacing">Character Lab</h1>
            <p className="text-[#a89f91] mb-12">Crie, modifique e armazene personas digitais para seus prompts.</p>
            
            <div className="grid lg:grid-cols-3 gap-8 mb-16">
                 <div className="lg:col-span-1 bg-[#241a15] border border-[#3a2d25] p-8 rounded-3xl relative overflow-hidden">
                     {!canCreate && <div className="absolute inset-0 bg-[#1a120b]/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center"><Lock size={32} className="text-[#d4b483] mb-4" /><button onClick={onGoToPricing} className="bg-[#e5e5e5] text-[#1a120b] px-6 py-2 rounded-full font-bold uppercase tracking-widest text-[10px]">Upgrade to Pro</button></div>}
                     <div className="flex justify-between items-center mb-6">
                         <h3 className="font-bold text-[#d4b483] uppercase tracking-widest text-xs flex items-center gap-2"><Plus size={14}/> Criar Novo</h3>
                         <button onClick={handleRandomize} className="text-[#e5e5e5] hover:text-[#d4b483] p-2 rounded-lg border border-[#3a2d25] hover:bg-[#3a2d25] transition-colors" title="Gerar Aleatório"><Dices size={16}/></button>
                     </div>
                     <div className="space-y-4">
                         <input className="w-full p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm text-[#e5e5e5]" placeholder="Nome (ex: Elara)" value={newChar.name} onChange={e => setNewChar({...newChar, name: e.target.value})} />
                         <div className="grid grid-cols-2 gap-4">
                            <input className="p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm" placeholder="Idade" type="number" value={newChar.age} onChange={e => setNewChar({...newChar, age: parseInt(e.target.value)})} />
                            <input className="p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm" placeholder="País" value={newChar.country} onChange={e => setNewChar({...newChar, country: e.target.value})} />
                         </div>
                         <input className="w-full p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm" placeholder="Cabelo" value={newChar.hair} onChange={e => setNewChar({...newChar, hair: e.target.value})} />
                         <input className="w-full p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm" placeholder="Olhos" value={newChar.eyes} onChange={e => setNewChar({...newChar, eyes: e.target.value})} />
                         <textarea className="w-full p-3 bg-[#1a120b] border border-[#3a2d25] rounded-xl text-sm h-24" placeholder="Descrição detalhada do corpo e rosto..." value={newChar.desc} onChange={e => setNewChar({...newChar, desc: e.target.value})} />
                         <button onClick={handleSubmit} className="w-full py-3 bg-[#d4b483] text-[#1a120b] font-bold rounded-xl uppercase tracking-widest text-xs hover:bg-[#c4a473]">Salvar & Gerar Prompts</button>
                     </div>
                 </div>

                 <div className="lg:col-span-2 grid md:grid-cols-2 gap-6">
                     {characters.map(char => (
                         <div key={char.id} onClick={() => onSelect(char.id)} className="bg-[#1a120b] border border-[#3a2d25] rounded-2xl p-6 hover:border-[#d4b483] transition-all group cursor-pointer relative">
                             <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                <ArrowRight size={16} className="text-[#d4b483]" />
                             </div>
                             <div className="flex justify-between items-start mb-4">
                                 <h3 className="text-xl font-bold">{char.name}</h3>
                                 <span className="text-[10px] font-bold uppercase tracking-widest text-[#5c473d] bg-[#241a15] px-2 py-1 rounded">{char.country}</span>
                             </div>
                             <p className="text-sm text-[#a89f91] mb-4 line-clamp-3">{char.desc}</p>
                             <div className="flex gap-2 text-xs text-[#5c473d]">
                                 <span>{char.age} anos</span> • <span>{char.style}</span>
                             </div>
                         </div>
                     ))}
                 </div>
            </div>
        </div>
    );
};

const MarketplacePage: React.FC<{ prompts: Prompt[], userTier: Tier, filterCharId: string | null, onClearFilter: () => void, onOpenPrompt: (p: Prompt) => void }> = ({ prompts, userTier, filterCharId, onClearFilter, onOpenPrompt }) => {
    // Smart Filtering Logic
    let displayPrompts = prompts;

    // Filter by character if clicked
    if (filterCharId) {
        displayPrompts = displayPrompts.filter(p => p.tags.includes(filterCharId));
    }

    // Tier Logic: Free users only see first 4 prompts of any category/char grouping
    // This is a simple simulation of limiting visibility
    if (userTier === 'free') {
        // We will just slice the whole array to simulate limit for demo purposes
        // Ideally complex backend logic
        displayPrompts = displayPrompts.slice(0, 12); 
    }

    return (
        <div className="pt-32 pb-20 max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
               <h2 className="text-4xl font-bold mb-4 editorial-spacing">Marketplace</h2>
               <p className="text-[#a89f91]">Prompts gerados automaticamente com nosso motor de câmeras aleatórias.</p>
               {filterCharId && (
                   <button onClick={onClearFilter} className="mt-4 px-4 py-2 bg-[#241a15] text-[#d4b483] rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2 mx-auto">
                       Filtrando: {filterCharId} <X size={14}/>
                   </button>
               )}
            </div>
            
            {userTier === 'free' && (
                <div className="mb-8 p-4 bg-yellow-900/20 border border-yellow-900/50 rounded-xl text-center">
                    <p className="text-yellow-500 text-xs font-bold uppercase tracking-widest">Modo Free: Visualização Limitada. Faça upgrade para ver todos os prompts.</p>
                </div>
            )}

            <div className="grid md:grid-cols-3 gap-6">
               {displayPrompts.map((p: Prompt) => (
                   <div key={p.id} className="bg-[#241a15] rounded-2xl p-6 border border-[#3a2d25] hover:border-[#a89f91] transition-colors relative group">
                       <div className="flex justify-between items-start mb-4">
                           <span className="px-2 py-1 rounded bg-[#3a2d25] text-[10px] uppercase font-bold text-[#d4b483]">{p.category}</span>
                           {p.isPremium && <Crown size={14} className="text-[#d4b483]" />}
                       </div>
                       <h3 className="font-bold mb-2">{p.title}</h3>
                       <p className="text-xs text-[#a89f91] mb-4 line-clamp-2">{p.description}</p>
                       <div className="flex gap-2 overflow-x-auto pb-2 mb-2 no-scrollbar">
                           {p.tags.slice(0,3).map(t => <span key={t} className="text-[9px] bg-[#1a120b] px-2 py-1 rounded text-[#5c473d] whitespace-nowrap">#{t}</span>)}
                       </div>
                       
                       <button onClick={() => onOpenPrompt(p)} className="w-full py-2 border border-[#3a2d25] rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-[#d4b483] hover:text-[#1a120b] transition-colors flex items-center justify-center gap-2">
                           <Maximize2 size={12}/> Ver Prompt
                       </button>
                   </div>
               ))}
            </div>
            
            {displayPrompts.length === 0 && <div className="text-center text-[#5c473d] py-20">Nenhum prompt encontrado.</div>}
        </div>
    );
};

const App: React.FC = () => {
    const [path, setPath] = useState(window.location.hash || '#home');
    const [user, setUser] = useState<UserProfile>({ email: 'user@example.com', name: 'Demo User', tier: 'pro' });
    
    // Lifted State for data persistence
    const [characters, setCharacters] = useState<Character[]>(CHARACTERS);
    const [prompts, setPrompts] = useState<Prompt[]>(PROMPTS);
    const [marketplaceFilter, setMarketplaceFilter] = useState<string | null>(null);
    const [selectedPrompt, setSelectedPrompt] = useState<Prompt | null>(null);

    useEffect(() => {
        const onHashChange = () => setPath(window.location.hash || '#home');
        window.addEventListener('hashchange', onHashChange);
        return () => window.removeEventListener('hashchange', onHashChange);
    }, []);

    // Load Data from Supabase
    useEffect(() => {
        if (!isSupabaseConfigured()) return;
        
        const loadSupabaseData = async () => {
             // 1. Load Characters
             const { data: dbChars } = await supabase.from('characters').select('*');
             if (dbChars && dbChars.length > 0) {
                 const mergedChars = [...CHARACTERS, ...dbChars.map(mapCharFromDB)];
                 // Dedup based on ID
                 const uniqueChars = Array.from(new Map(mergedChars.map(c => [c.id, c])).values());
                 setCharacters(uniqueChars);
             }

             // 2. Load Prompts
             const { data: dbPrompts } = await supabase.from('prompts').select('*');
             if (dbPrompts && dbPrompts.length > 0) {
                 const mergedPrompts = [...PROMPTS, ...dbPrompts.map(mapPromptFromDB)];
                 const uniquePrompts = Array.from(new Map(mergedPrompts.map(p => [p.id, p])).values());
                 setPrompts(uniquePrompts);
             }
        };

        loadSupabaseData();
    }, []);

    const navigate = (p: string) => { window.location.hash = p; setPath(p); };

    const handleAddCharacter = async (c: Character) => {
        // Optimistic Update
        setCharacters(prev => [...prev, c]);
        const newPrompts = generatePromptsForCharacter(c, prompts.length);
        setPrompts(prev => [...newPrompts, ...prev]); 
        
        // Supabase Sync
        if (isSupabaseConfigured()) {
            try {
                await supabase.from('characters').insert(mapCharToDB(c));
                // Batch insert prompts
                const dbPrompts = newPrompts.map(mapPromptToDB);
                await supabase.from('prompts').insert(dbPrompts);
            } catch (e) {
                console.error("Failed to sync to Supabase:", e);
            }
        }
        
        // Auto navigate to marketplace and filter
        setMarketplaceFilter(c.id);
        navigate('#marketplace');
    };

    const handleSelectCharacter = (id: string) => {
        setMarketplaceFilter(id);
        navigate('#marketplace');
    };

    const renderPage = () => {
        if (path === '#generator') return <GeneratorPage allCharacters={characters} userTier={user.tier} onGoToPricing={() => navigate('#pricing')} />;
        if (path === '#characters') return <CharacterPage characters={characters} userTier={user.tier} onAdd={handleAddCharacter} onGoToPricing={() => navigate('#pricing')} onSelect={handleSelectCharacter} />;
        if (path === '#pricing') return (
            <div className="pt-32 pb-20 max-w-7xl mx-auto px-4">
                <div className="text-center mb-16">
                    <h2 className="text-5xl font-bold mb-4 editorial-spacing">Planos & Acesso</h2>
                    <p className="text-[#a89f91]">Escolha o nível de poder do seu estúdio criativo.</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    {/* Free */}
                    <div className={`p-8 rounded-[2rem] border transition-all ${user.tier === 'free' ? 'bg-[#e5e5e5] text-[#1a120b] border-transparent' : 'bg-[#241a15] border-[#3a2d25]'}`}>
                        <div className="mb-8"><span className="text-xs font-bold uppercase tracking-widest opacity-60">Iniciante</span><div className="text-4xl font-bold mt-2">Free</div></div>
                        <ul className={`space-y-4 mb-8 text-sm ${user.tier === 'free' ? 'text-[#3a2d25]' : 'text-[#a89f91]'}`}>
                            <li className="flex items-center gap-2"><Check size={14}/> Acesso Limitado Marketplace (4/char)</li>
                            <li className="flex items-center gap-2 opacity-50"><X size={14}/> Gerador Bloqueado</li>
                            <li className="flex items-center gap-2 opacity-50"><X size={14}/> Sem IA Generativa</li>
                        </ul>
                        <button onClick={() => setUser(u => ({...u, tier: 'free'}))} className="w-full py-4 border border-current rounded-xl text-xs font-bold uppercase tracking-widest hover:opacity-70">{user.tier === 'free' ? 'Plano Atual' : 'Selecionar'}</button>
                    </div>
                    {/* Lite */}
                    <div className={`p-8 rounded-[2rem] border transition-all ${user.tier === 'lite' ? 'bg-[#e5e5e5] text-[#1a120b] border-transparent' : 'bg-[#241a15] border-[#3a2d25]'}`}>
                        <div className="mb-8"><span className="text-xs font-bold uppercase tracking-widest text-blue-400">Criador</span><div className="text-4xl font-bold mt-2">$12.00</div></div>
                        <ul className={`space-y-4 mb-8 text-sm ${user.tier === 'lite' ? 'text-[#3a2d25]' : 'text-[#a89f91]'}`}>
                            <li className="flex items-center gap-2"><Check size={14}/> Marketplace Ilimitado</li>
                            <li className="flex items-center gap-2"><Check size={14}/> Gerador Estático (Montagem)</li>
                            <li className="flex items-center gap-2 opacity-50"><X size={14}/> Sem Criação de Personagem IA</li>
                        </ul>
                        <button onClick={() => setUser(u => ({...u, tier: 'lite'}))} className="w-full py-4 border border-current rounded-xl text-xs font-bold uppercase tracking-widest hover:opacity-70">{user.tier === 'lite' ? 'Plano Atual' : 'Selecionar'}</button>
                    </div>
                    {/* Pro (Highlighted) */}
                    <div className={`p-8 rounded-[2rem] border transition-all relative overflow-hidden ${user.tier === 'pro' ? 'bg-[#e5e5e5] text-[#1a120b] border-transparent shadow-2xl' : 'bg-[#1a120b] border-[#d4b483] shadow-2xl shadow-[#d4b483]/10 transform scale-105'}`}>
                         <div className="absolute top-0 right-0 bg-[#d4b483] text-[#1a120b] text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-bl-2xl rounded-tr-2xl">Recomendado</div>
                        <div className="mb-8"><span className="text-xs font-bold uppercase tracking-widest text-[#d4b483]">Profissional</span><div className="text-4xl font-bold mt-2">$19.50</div></div>
                        <ul className={`space-y-4 mb-8 text-sm ${user.tier === 'pro' ? 'text-[#3a2d25]' : 'text-[#e5e5e5]'}`}>
                            <li className="flex items-center gap-2"><Check size={14}/> Automação (8 prompts/char novo)</li>
                            <li className="flex items-center gap-2"><Check size={14}/> Remix IA + Lore + Tech Specs</li>
                            <li className="flex items-center gap-2"><Check size={14}/> Character Lab Ilimitado</li>
                            <li className="flex items-center gap-2"><Check size={14}/> Geração DALL-E 3</li>
                        </ul>
                        <button onClick={() => setUser(u => ({...u, tier: 'pro'}))} className="w-full py-4 bg-[#d4b483] text-[#1a120b] rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-[#c4a473]">{user.tier === 'pro' ? 'Plano Atual' : 'Ativar Agora'}</button>
                    </div>
                </div>
            </div>
        );
        if (path === '#marketplace') return <MarketplacePage prompts={prompts} userTier={user.tier} filterCharId={marketplaceFilter} onClearFilter={() => setMarketplaceFilter(null)} onOpenPrompt={setSelectedPrompt} />;
        return <HomePage onNavigate={navigate} />;
    };

    return (
        <div className="min-h-screen bg-[#1a120b] text-[#e5e5e5] font-sans selection:bg-[#d4b483] selection:text-[#1a120b]">
            <Navbar currentPath={path} onNavigate={navigate} user={user} />
            {renderPage()}
            {selectedPrompt && <PromptModal prompt={selectedPrompt} onClose={() => setSelectedPrompt(null)} />}
        </div>
    );
};

export default App;
