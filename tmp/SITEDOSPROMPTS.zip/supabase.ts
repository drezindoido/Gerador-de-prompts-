
import { createClient } from '@supabase/supabase-js';
import { Character, Prompt } from './types';

// ⚠️ PLEASE REPLACE WITH YOUR SUPABASE PROJECT URL (Settings > API)
const SUPABASE_URL = "https://REPLACE_WITH_YOUR_PROJECT_ID.supabase.co"; 
const SUPABASE_KEY = "sb_secret__c18d1jyF5RgH0NRpNKayQ_mMfjpyqq";

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export const isSupabaseConfigured = () => {
    return SUPABASE_URL !== "https://REPLACE_WITH_YOUR_PROJECT_ID.supabase.co";
};

// --- Data Mappers (Frontend CamelCase <-> DB SnakeCase) ---

export const mapCharToDB = (c: Character) => ({
    id: c.id,
    name: c.name,
    age: c.age,
    country: c.country,
    hair: c.hair,
    eyes: c.eyes,
    style: c.style,
    desc: c.desc,
    is_premium: c.isPremium,
    rules: c.rules
});

export const mapCharFromDB = (c: any): Character => ({
    id: c.id,
    name: c.name,
    age: c.age,
    country: c.country,
    hair: c.hair,
    eyes: c.eyes,
    style: c.style,
    desc: c.desc,
    isPremium: c.is_premium,
    rules: c.rules
});

export const mapPromptToDB = (p: Prompt) => ({
    id: p.id,
    title: p.title,
    description: p.description,
    full_prompt: p.fullPrompt,
    tags: p.tags,
    is_premium: p.isPremium,
    category: p.category,
    model_recommendation: p.modelRecommendation
});

export const mapPromptFromDB = (p: any): Prompt => ({
    id: p.id,
    title: p.title,
    description: p.description,
    fullPrompt: p.full_prompt,
    tags: p.tags,
    isPremium: p.is_premium,
    category: p.category,
    modelRecommendation: p.model_recommendation
});
